import React from 'react'

function SideBox() {
    return (
        <div>
            Side
        </div>
    )
}

export default SideBox
